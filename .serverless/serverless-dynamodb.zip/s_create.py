import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='aromdap',
    application_name='api-restful-todo',
    app_uid='6rgn4VCNlrHBKpwKSP',
    org_uid='98f5f36c-f963-433c-990c-c8e5784d10e1',
    deployment_uid='77bfb9c4-9d2c-4d00-a07f-65a6a0d5e329',
    service_name='serverless-dynamodb',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='3.8.4',
    disable_frameworks_instrumentation=False
)
handler_wrapper_kwargs = {'function_name': 'serverless-dynamodb-dev-create', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('todos/create.create')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
